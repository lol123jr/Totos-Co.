package com.example.demo3.DAO;
import java.util.List;
import com.example.demo3.Entity.*;

public class CustomerDAO extends UserDAO {

    private CartDAO cart;  // CartDAO instance to handle cart operations
    private CustomerEntity customer;  // Customer instance

    // Constructor that initializes CustomerDAO with a CustomerEntity
    public CustomerDAO(CustomerEntity customer) {
        this.customer = customer;  // Set the customer
        this.cart = new CartDAO(customer);  // Initialize the CartDAO with the customer
    }

    @Override
    public boolean Login(String username, String password) {
        // Assuming the login credentials are stored in CustomerEntity
        return this.customer.getUsername().equals(username) && this.customer.getPassword().equals(password);
    }

    // Add product to the customer's cart
    public void addToCart(ProductsEntity product) {
        cart.addProduct(product);
    }

    // Remove product from the customer's cart
    public void removeFromCart(ProductsEntity product) {
        if (cart.containsProduct(product)) {  // Checking if product is in the cart
            cart.removeProduct(product);
            System.out.println("Product removed from cart.");
        } else {
            System.out.println("Product not found in cart.");
        }
    }

    // Display the contents of the customer's cart
    public void displayCartContents() {
        cart.displayCartContents(customer);
    }

    // Remove product by its ID
    public void removeProductById(int productId) {
        ProductsEntity product = cart.getProductById(productId);
        if (product != null) {
            cart.removeProduct(product);
            System.out.println("Product removed from cart.");
        } else {
            System.out.println("Product with ID " + productId + " not found in cart.");
        }
    }

    // Get the current balance of the customer
    public double getBalance() {
        return customer.getBalance();  // Access balance through CustomerEntity
    }

    // Reduce balance by a specified amount
    public void reduceBalance(double amount) {
        if (customer.getBalance() >= amount) {
            customer.setBalance(customer.getBalance() - amount);  // Update balance
        } else {
            throw new IllegalArgumentException("Insufficient balance!");
        }
    }

    @Override
    public String toString() {
        return "Customer{" +
                "username='" + customer.getUsername() + '\'' +
                ", gender='" + customer.getGender() + '\'' +  // Access gender through CustomerEntity
                ", balance=" + customer.getBalance() +
                '}';
    }

    // Get the CartDAO instance for this customer
    public CartDAO getCart() {
        return cart;
    }

    // Set the customer instance
    public void setCustomer(CustomerEntity customer) {
        this.customer = customer;
        this.cart = new CartDAO(customer);  // Reinitialize CartDAO with the new customer
    }
}
