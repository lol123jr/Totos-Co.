package com.example.demo3.DAO;

import com.example.demo3.Entity.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {

    private static CartDAO instance;
    private CustomerEntity customer;  // Customer instance associated with the cart
    private List<ProductsEntity> products;  // List of products in the cart

    // Constructor that takes the CustomerEntity object
    public CartDAO(CustomerEntity customer) {
        this.customer = customer;
        this.products = new ArrayList<>();
    }

    public static CartDAO getInstance(CustomerEntity customer) {
        if (instance == null) {
            instance = new CartDAO(customer);
        }
        return instance;
    }


    // Add product to cart
    public void addProduct(ProductsEntity product) {
        products.add(product);
    }

    // Remove product from cart
    public void removeProduct(ProductsEntity product) {
        products.remove(product);
    }

    public double calculateTotal(){

        return products.stream().mapToDouble(ProductsEntity::getPrice).sum();
    }

    // Check if product is in cart
    public boolean containsProduct(ProductsEntity product) {
        return products.contains(product);
    }

    // Get product by its ID
    public ProductsEntity getProductById(int productId) {
        for (ProductsEntity product : products) {
            if (product.getProductID() == productId) {
                return product;
            }
        }
        return null;
    }

    // Display the contents of the cart
    public void displayCartContents(CustomerEntity customer) {
        if (products.isEmpty()) {
            System.out.println("Your cart is empty!");
        } else {
            System.out.println("Products in your cart for customer " + customer.getUsername() + ":");
            for (ProductsEntity product : products) {
                System.out.println(product.getProductName());
            }
        }
    }

    // Get list of products in the cart
    public List<ProductsEntity> getProducts() {
        return products;
    }

    // Clear the cart
    public void clear() {
        products.clear();
    }


}
