package com.example.demo3.Service;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.Entity.ProductsEntity;
import com.example.demo3.Entity.CustomerEntity;
import java.util.List;

public class CartService {

    private CartDAO cartDAO; // DAO instance to interact with cart data
    private CustomerEntity customer; // The customer whose cart we are managing

    // Constructor now requires a CustomerEntity to initialize CartDAO
    public CartService(CustomerEntity customer) {
        this.customer = customer;
        this.cartDAO = new CartDAO(customer); // Pass the customer to CartDAO constructor
    }

    // Add a product to the customer's cart
    public void addProductToCart(ProductsEntity product) {
        cartDAO.addProduct(product);
        System.out.println("Product " + product.getProductName() + " added to the cart.");
    }

    // Remove a product from the customer's cart
    public void removeProductFromCart(ProductsEntity product) {
        if (cartDAO.containsProduct(product)) {
            cartDAO.removeProduct(product);
            System.out.println("Product " + product.getProductName() + " removed from the cart.");
        } else {
            System.out.println("Product not found in the cart.");
        }
    }

    // Get the list of products in the customer's cart
    public List<ProductsEntity> getCartProducts() {
        return cartDAO.getProducts();
    }

    // Get the total price of the cart
    public double getTotalPrice() {
        return cartDAO.calculateTotal();
    }

    // Display the cart's contents
    public void displayCartContents() {
        List<ProductsEntity> productsInCart = getCartProducts();
        if (productsInCart.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("Products in your cart:");
            for (ProductsEntity product : productsInCart) {
                System.out.println(product.getProductName() + " - " + product.getPrice());
            }
        }
    }

    // Check if the cart contains a specific product
    public boolean isProductInCart(ProductsEntity product) {
        return cartDAO.containsProduct(product);
    }

    // Get the customer associated with this cart service
    public CustomerEntity getCustomer() {
        return customer;
    }
}
