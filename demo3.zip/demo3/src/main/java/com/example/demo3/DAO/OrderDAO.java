package com.example.demo3.DAO;

import com.example.demo3.Entity.OrderEntity;
import com.example.demo3.Entity.ProductsEntity;
import java.util.List;

public class OrderDAO {

    // Method to calculate total for an order
    public static double calculateTotal(List<ProductsEntity> products) {
        double total = 0;
        for (ProductsEntity product : products) {
            total += product.getPrice();  // Summing the prices of all products
        }
        return total;
    }

    // Method to display an order details (for example)
    public String toString(OrderEntity order) {
        return "Order{" +
                "customer=" + order.getCustomer().getUsername() +
                ", totalAmount=" + order.getTotalAmount() +
                ", paymentMethod=" + order.getPaymentMethod() +
                '}';
    }
}
