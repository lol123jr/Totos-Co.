package com.example.demo3.Entity;

public class AdminEntity extends UserEntity{
    private String role;
    private int workingHours;


    // Constructor
    public AdminEntity(String username, String password, String DateOfBirth, String role, int workingHours) {
        super(username, password, DateOfBirth);
        this.role = role;
        this.workingHours = workingHours;
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    @Override
    public String getUsername() {
        return super.getUsername();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }



}