package com.example.demo3.Service;
import java.util.Scanner;

import com.example.demo3.DAO.*;
import com.example.demo3.Entity.*;
import com.example.demo3.Database.*;

public class AdminService {

    private AdminDAO adminDAO;
    private ProductsDAO productsDAO;

    public AdminService() {
        this.adminDAO = new AdminDAO();
        this.productsDAO = new ProductsDAO();
    }

    public void addProduct(ProductsEntity product) {
        adminDAO.addProduct(product);
        System.out.println("Product added: " + product.getProductName());
    }

    public void removeProduct(int productId) {
        adminDAO.removeProduct(productId);
        System.out.println("Product removed with ID: " + productId);
    }

    public void showAllOrders() {
        adminDAO.showAllOrders();
    }

    public void showAllProducts() {
        adminDAO.showAllProducts();
    }

    public void updateProductDetails(int productId, Scanner scanner) {
        adminDAO.updateProductDetails(productId, scanner);
    }


    public boolean login(String username, String password) {
        // Check the list of admins (assuming Database contains the list of admins)
        for (AdminEntity admin : Database.admins) {
            // Call the login method in AdminEntity (or you can directly check credentials here)
            if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                System.out.println("Login successful for admin: " + username);
                return true;  // Valid credentials
            }
        }
        System.out.println("Login failed. Invalid username or password.");
        return false;  // Invalid credentials
    }



}
