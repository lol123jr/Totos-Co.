package com.example.demo3.Entity;


public abstract class UserEntity {
    protected String username;
    protected String password;
    protected String DateOfBirth;


    public UserEntity(String username, String password, String DateOfBirth) {
        this.username = username;
        this.password = password;
        this.DateOfBirth = DateOfBirth;

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setDateOfBirth(String dateOfBirth) {
        DateOfBirth = dateOfBirth;
    }

    public String getDateOfBirth() {
        return DateOfBirth;
    }
}