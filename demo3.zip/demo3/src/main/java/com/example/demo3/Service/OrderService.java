package com.example.demo3.Service;

import com.example.demo3.DAO.OrderDAO;
import com.example.demo3.Entity.OrderEntity;
import com.example.demo3.Entity.ProductsEntity;

import java.util.List;

public class OrderService {

    private OrderDAO orderDAO;  // DAO instance to interact with order data

    public OrderService() {
        this.orderDAO = new OrderDAO();  // Initialize OrderDAO for this service
    }

    // Calculate the total for an order
    public double calculateTotal(List<ProductsEntity> products) {
        return orderDAO.calculateTotal(products);  // Using the OrderDAO to calculate the total
    }
}
