package com.example.demo3;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.DAO.ProductsDAO;
import com.example.demo3.Database.*;
import com.example.demo3.Entity.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HelloController {

    @FXML
    private Button ModifyMenu;

    @FXML
    private Label loginMessageLabel;

    @FXML
    private TextField usernameTextField;

    @FXML
    private TextField NewAdminDate;

    @FXML
    private TextField NewAdminHours;

    @FXML
    private TextField NewAdminRole;

    @FXML
    private PasswordField passwordPasswordField;

    @FXML
    private Button SignOutButton;

    @FXML
    private Button GoBack;

    @FXML
    private Button ShowCustomersButton;

    @FXML
    private TextArea ShowCustomersField;

    @FXML
    private Button LogOutButton;

    @FXML
    private Button NewAdmin;

    @FXML
    private Label AdminErrorMessage;

    @FXML
    private Label SignupField;

    @FXML
    private Button Signup;

    @FXML
    private TextField SignupDate;

    @FXML
    private TextField SignupBalance;

    @FXML
    private TextField SignupInterests;

    @FXML
    private TextField SignupGender;

    @FXML
    private Button SignupButton;

    @FXML
    private TextField SignUpAddress;


    private CustomerEntity loggedInCustomer;

    // CartDAO instance to manage cart operations
    private CartDAO cartDAO;

    // ProductsDAO instance to manage product details
    private ProductsDAO productsDAO;

    public HelloController() {
        // Initialize the ProductsDAO here
        productsDAO = new ProductsDAO();
        // You can initialize productsDAO with a real or mock database connection if needed
    }




    public void setProductsDAO(ProductsDAO productsDAO) {
        this.productsDAO = productsDAO;
    }

    public void goToModifyMenu(ActionEvent event) {
        try {
            setProductsDAO(productsDAO);
            // Load the ModifyMenu.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifyMenu.fxml"));
            Parent root = loader.load();

            // Optionally, you can pass data to the next controller
            ModifyMenuController modifyMenuController = loader.getController();
            modifyMenuController.setProductsDAO(productsDAO);

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);

            // Update the stage title (optional)
            stage.setTitle("Modify Menu");

            // Show the new scene
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle any errors (e.g., FXML not found)
        }
    }

    // Navigate to Admin view
    public void goBackToAdmin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) GoBack.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    public void NewAdminButtonOnAction(ActionEvent e) {
        // Check if both username and password fields are filled
        if (!usernameTextField.getText().isBlank() && !passwordPasswordField.getText().isBlank() &&
                !NewAdminDate.getText().isBlank() && !NewAdminHours.getText().isBlank() && !NewAdminRole.getText().isBlank()) {

            // Get the entered data from the fields
            String enteredUsername = usernameTextField.getText();
            String enteredPassword = passwordPasswordField.getText();
            String DateOfBirth = NewAdminDate.getText();
            String WorkingHours = NewAdminHours.getText();
            String Role = NewAdminRole.getText();

            // Create a new AdminEntity with the data
            AdminEntity newAdmin = new AdminEntity(enteredUsername, enteredPassword, DateOfBirth, Role, Integer.parseInt(WorkingHours));

            // Add the new admin to the list of admins (in the Database class or wherever admins are stored)
            Database.admins.add(newAdmin);

            // Show a success message (you could change the label text for this)
            AdminErrorMessage.setText("New admin added successfully!");

            // Optionally, clear the fields after successful addition
            passwordPasswordField.clear();
            usernameTextField.clear();
            NewAdminDate.clear();
            NewAdminHours.clear();
            NewAdminRole.clear();
        } else {
            // If any field is blank, show an error message
            AdminErrorMessage.setText("Please enter all fields (Username, Password, Date of Birth, Working Hours, Role).");
        }

    }


    public void SignUpButtonOnAction(ActionEvent e) {
        // Check if all fields are filled
        if (!usernameTextField.getText().isBlank() &&
                !passwordPasswordField.getText().isBlank() &&
                !SignupDate.getText().isBlank() &&
                !SignupBalance.getText().isBlank() &&
                !SignupGender.getText().isBlank() &&
                !SignupInterests.getText().isBlank() &&
                !SignUpAddress.getText().isBlank()) {

            try {
                // Get the entered data from the fields
                String enteredUsername = usernameTextField.getText();
                String enteredPassword = passwordPasswordField.getText();
                String dateOfBirth = SignupDate.getText();
                double balance = Double.parseDouble(SignupBalance.getText());
                Gender gender = Gender.valueOf(SignupGender.getText().toUpperCase()); // Ensure gender matches enum
                List<String> interests = Arrays.asList(SignupInterests.getText().split(","));
                String Address = SignUpAddress.getText();

                // Create a new CustomerEntity with the entered data
                CustomerEntity newCustomer = new CustomerEntity(
                        enteredUsername,
                        enteredPassword,
                        dateOfBirth,
                        balance,
                        Address, // Placeholder for address
                        gender,
                        interests
                );

                // Add the new customer to the list of customers (in the Database class)
                Database.customers.add(newCustomer);

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
                    Parent root = loader.load();

                    Stage stage = (Stage) Signup.getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (Exception a) {
                    a.printStackTrace(); // Handle exception if loading FXML fails
                }

                // Show a success message
                SignupField.setText("New customer added successfully!");

                // Optionally, clear the fields after successful addition
                passwordPasswordField.clear();
                usernameTextField.clear();
                SignupDate.clear();
                SignupBalance.clear();
                SignupGender.clear();
                SignupInterests.clear();
            } catch (NumberFormatException ex) {
                SignupField.setText("Please enter a valid number for Balance.");
            } catch (IllegalArgumentException ex) {
                SignupField.setText("Please enter a valid Gender (MALE/FEMALE).");
            }
        } else {
            // If any field is blank, show an error message
            SignupField.setText("Please enter all fields (Username, Password, Date of Birth, Balance, Gender, Interests).");
        }
    }

    public void SignOut() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            HelloController helloController = loader.getController();


            Stage stage = (Stage) SignOutButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }




    // Navigate to New Admin view
    public void goToSignUp() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Signup.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) SignupButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    public void goToNewAdmin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("NewAdmin.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) NewAdmin.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    // Navigate back to the login page
    public void goBackTologin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) LogOutButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    // Display all customers in the TextArea
    public void displayAllCustomers() {
        List<CustomerEntity> customers = Database.customers;
        StringBuilder customerDetails = new StringBuilder();
        for (CustomerEntity customer : customers) {
            customerDetails.append(customer.toString()); // Using the overridden toString() method of CustomerEntity
        }
        ShowCustomersField.setText(customerDetails.toString());
    }

    // Navigate to ShowCustomers page
    public void goToShowCustomers() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowCustomers.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) ShowCustomersButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    // Handle customer login
    public void loginCustomerButtonOnAction(ActionEvent e) {
        if (!usernameTextField.getText().isBlank() && !passwordPasswordField.getText().isBlank()) {
            String enteredUsername = usernameTextField.getText();
            String enteredPassword = passwordPasswordField.getText();

            boolean loginSuccessful = false;
            for (CustomerEntity customer : Database.customers) {
                if (customer.getUsername().equals(enteredUsername) && customer.getPassword().equals(enteredPassword)) {
                    loggedInCustomer = customer;
                    loginSuccessful = true;
//                    loggedInRole = "customer";
                    break;
                }
            }

            if (loginSuccessful) {
                loginMessageLabel.setText("Login successful!");
                //initializeButtonList(); // Initialize buttons only after login
               // adjustButtonForRole(buttonList); // Adjust button states based on role

                if (cartDAO == null) {
                    cartDAO = new CartDAO(loggedInCustomer);
                }

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Electronics.fxml"));
                    Parent root = loader.load();

                    ElectronicsController electronicsController = loader.getController();
                    electronicsController.setCartDAO(cartDAO);
                    electronicsController.setLoggedInCustomer(loggedInCustomer);


                    Stage stage = (Stage) loginMessageLabel.getScene().getWindow();
                    Scene newScene = new Scene(root);
                    stage.setScene(newScene);
                    stage.show();

                } catch (Exception ex) {
                    ex.printStackTrace();
                    loginMessageLabel.setText("Error loading the new page.");
                }
            } else {
                loginMessageLabel.setText("Invalid username or password.");
            }
        } else {
            loginMessageLabel.setText("Please enter username and password.");
        }
    }

    // Handle admin login
    public void loginAdminButtonOnAction(ActionEvent e) {
        if (!usernameTextField.getText().isBlank() && !passwordPasswordField.getText().isBlank()) {
            String enteredUsername = usernameTextField.getText();
            String enteredPassword = passwordPasswordField.getText();

            boolean loginSuccessful = false;
            for (AdminEntity admin : Database.getAdmins()) {
                if (admin.getUsername().equals(enteredUsername) && admin.getPassword().equals(enteredPassword)) {
                    loginSuccessful = true;
//                    loggedInRole = "admin";
                    break;
                }
            }

            if (loginSuccessful) {
                loginMessageLabel.setText("Login successful!");
                //initializeButtonList(); // Initialize buttons only after login
                //adjustButtonForRole(buttonList); // Adjust button states based on role

                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
                    Parent newPageRoot = loader.load();

                    Stage stage = (Stage) loginMessageLabel.getScene().getWindow();
                    Scene newScene = new Scene(newPageRoot);
                    stage.setScene(newScene);
                    stage.show();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    loginMessageLabel.setText("Error loading the new page.");
                }
            } else {
                loginMessageLabel.setText("Invalid username or password.");
            }
        } else {
            loginMessageLabel.setText("Please enter username and password.");
        }
    }

    // Navigate to Modify Menu
    public void goToMenu() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Electronics.fxml"));
            Parent root = loader.load();

            ElectronicsController electronicsController = loader.getController();
            electronicsController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) ModifyMenu.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

}
