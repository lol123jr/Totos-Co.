package com.example.demo3.Database;

import com.example.demo3.Entity.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Database {
    public static List<CustomerEntity> customers = new ArrayList<>();
    public static List<AdminEntity> admins = new ArrayList<>();
    public static List<ProductsEntity> products = new ArrayList<>();
    public static List<OrderEntity> orders = new ArrayList<>();

    public static List<AdminEntity> getAdmins() {
        return admins;
    }

    public static List<ProductsEntity> getVegetablesProducts() {
        return products.stream()
                .filter(product -> "Vegetables".equals(product.getCategory()))
                .collect(Collectors.toList());
    }

    public static List<ProductsEntity> getElectronicsProducts() {
        return products.stream()
                .filter(product -> "Electronics".equals(product.getCategory()))
                .collect(Collectors.toList());
    }

    public static List<ProductsEntity> getFoodProducts() {
        return products.stream()
                .filter(product -> "Food".equals(product.getCategory()))
                .collect(Collectors.toList());
    }


    static {
        customers.add(new CustomerEntity("Loay", "password123", "1990-01-01", 500.0,
                "123 Street", Gender.MALE, Arrays.asList("Gaming", "Coding")));
        admins.add(new AdminEntity("Omar", "password123", "1985-05-05", "Manager", 40));
        admins.add(new AdminEntity("Omar", "password123", "1985-05-05", "Manager", 40));
        admins.add(new AdminEntity("Omar", "password123", "1985-05-05", "Manager", 40));
        admins.add(new AdminEntity("Omar", "password123", "1985-05-05", "Manager", 40));
        products.add(new ProductsEntity(2, "Phone", 500.0, "Electronics"));
        products.add(new ProductsEntity(1, "Headphones", 50.0, "Electronics"));
        products.add(new ProductsEntity(2, "Laptop", 100.0, "Electronics"));
        products.add(new ProductsEntity(3, "FlashDrive", 15.0, "Electronics"));
        products.add(new ProductsEntity(4, "Keyboard", 20.0, "Electronics"));
        products.add(new ProductsEntity(5, "Mouse", 25.0, "Electronics"));
        products.add(new ProductsEntity(6, "PowerBank", 80.0, "Electronics"));
        products.add(new ProductsEntity(7,"Hamburger",250,"Food"));
        products.add( new ProductsEntity(8,"Fries",6,"Food"));
        products.add(new ProductsEntity(9,"Sausages",150,"Food"));
        products.add(new ProductsEntity(10,"Spaghetti",50,"Food"));
        products.add( new ProductsEntity(11,"Shawarma",3,"Food"));
        products.add( new ProductsEntity(12,"Cheese",2,"Food"));
        products.add(new ProductsEntity(13,"Tomato",9,"Vegetables"));
        products.add(new ProductsEntity(14,"Cucumber",8,"Vegetables"));
        products.add(new ProductsEntity(15,"Lemon",7,"Vegetables"));
        products.add(new ProductsEntity(16,"Aubergine",12,"Vegetables"));
        products.add(new ProductsEntity(17,"Carrot",10,"Vegetables"));
        products.add(new ProductsEntity(18,"Pepper",11,"Vegetables"));

    }
}
