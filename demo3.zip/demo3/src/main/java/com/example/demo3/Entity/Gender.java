package com.example.demo3.Entity;

public enum Gender {
    MALE,
    FEMALE
}
