package com.example.demo3.Entity;

import java.util.ArrayList;
import java.util.List;

public class CartEntity {
    private CustomerEntity customer;
    private List<ProductsEntity> products;

    public CartEntity(CustomerEntity customer) {
        this.customer = customer;
        this.products = new ArrayList<>();
    }

//    // Add product to the cart
//    public void addProduct(ProductsEntity product) {
//        this.products.add(product);
//    }
//
//    // Remove product from the cart
//    public void removeProduct(ProductsEntity product) {
//        this.products.remove(product);
//    }

    // Clear all products from the cart
    public void clear() {
        this.products.clear();
    }

    // Get the products in the cart
    public List<ProductsEntity> getProducts() {
        return products;
    }

    // Display the cart contents
    @Override
    public String toString() {
        return "Cart{" +
                "customer=" + customer.getUsername() +
                ", products=" + products +
                '}';
    }

    // Getter for customer
//    public CustomerEntity getCustomer() {
//        return customer;
//    }
//
//    // Setter for customer
//    public void setCustomer(CustomerEntity customer) {
//        this.customer = customer;
//    }

    // Setter for products list
    public void setProducts(List<ProductsEntity> products) {
        this.products = products;
    }
}
