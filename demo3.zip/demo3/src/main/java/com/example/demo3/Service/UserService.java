package com.example.demo3.Service;

import com.example.demo3.DAO.UserDAO;
import com.example.demo3.Entity.UserEntity;

public class UserService {

    private UserDAO userDAO;  // DAO instance to interact with user data

    // Constructor initializes UserDAO for the service
    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    // Login function for user authentication
    public boolean login(String username, String password) {
        if (userDAO.Login(username, password)) {
            System.out.println("Login successful for username: " + username);
            return true;
        } else {
            System.out.println("Login failed. Invalid username or password.");
            return false;
        }
    }

    // Get username of the user
    public String getUsername() {
        return userDAO.getUsername();  // Retrieve username from the DAO
    }

    // Get password of the user
    public String getPassword() {
        return userDAO.getPassword();  // Retrieve password from the DAO
    }

    // Set a new username
    public void setUsername(String newUsername) {
        userDAO.setUsername(newUsername) ;  // Update username in DAO
        System.out.println("Username updated to: " + newUsername);
    }

    // Set a new password
    public void setPassword(String newPassword) {
        userDAO.setPassword(newPassword);  // Update password in DAO
        System.out.println("Password updated.");
    }

    // Get the full name or other details of the user
    public String getUserDetails() {
        UserEntity user = userDAO.getUserEntity();
        return "Username: " + user.getUsername() + ", Date of Birth: " + user.getDateOfBirth();
    }
}
