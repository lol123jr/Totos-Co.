package com.example.demo3;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.Database.Database;
import com.example.demo3.Entity.CustomerEntity;
import com.example.demo3.Entity.ProductsEntity;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Callback;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;

public class VegetablesController {

    @FXML
    private TableView<ProductsEntity> productsTable;

    @FXML
    private TableColumn<ProductsEntity, String> productNameColumn;

    @FXML
    private TableColumn<ProductsEntity, Double> productPriceColumn;

    @FXML
    private TableColumn<ProductsEntity, Void> actionColumn;

    @FXML
    private Button CartButton;

    private CartDAO cartDAO;
    private CustomerEntity loggedInCustomer;

    private ObservableList<ProductsEntity> products = FXCollections.observableArrayList();

    public void setLoggedInCustomer(CustomerEntity customer) {
        this.loggedInCustomer = customer;
        System.out.println("Logged in customer: " + customer.getUsername());
    }

    public void setCartDAO(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
    }

    @FXML
    private void initialize() {
        // Initialize table columns with PropertyValueFactory for binding
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Load vegetables from the database
        loadVegetablesFromDatabase();

        // Set the table items to the products list
        productsTable.setItems(products);

        // Add "Add to Cart" buttons to the action column
        addButtonToTable();
    }

    private void loadVegetablesFromDatabase() {
        // Get all products with category "Vegetables" from the Database
        products.clear();  // Clear existing list
        products.addAll(Database.getVegetablesProducts());  // Fetching only the "Vegetables" category products
    }

    // Add a product to the table
    public void addProductToTable(ProductsEntity newProduct) {
        if ("Vegetables".equals(newProduct.getCategory())) {
            products.add(newProduct); // Only add if it's a "Vegetables" category product
        }
    }

    // Remove a product from the table
    public void removeProductFromTable(ProductsEntity productToRemove) {
        products.remove(productToRemove);
    }

    // Modify an existing product in the table
    public void modifyProductInTable(ProductsEntity modifiedProduct) {
        int index = -1;
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProductID() == modifiedProduct.getProductID()) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            products.set(index, modifiedProduct);
        }
    }

    private void addButtonToTable() {
        Callback<TableColumn<ProductsEntity, Void>, TableCell<ProductsEntity, Void>> cellFactory = param -> new TableCell<>() {
            private final Button addButton = new Button("Add to Cart");

            {
                addButton.setOnAction(event -> {
                    ProductsEntity product = getTableView().getItems().get(getIndex());
                    if (product != null) {
                        if (cartDAO == null) {
                            System.out.println("Error: CartDAO is not initialized.");
                            return;
                        }
                        // Add product to cart
                        cartDAO.addProduct(product);
                        System.out.println(product.getProductName() + " has been added to the cart.");
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(addButton);
                }
            }
        };

        actionColumn.setCellFactory(cellFactory);
    }

    public void goToCart() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Cart.fxml"));
            Parent root = loader.load();

            CartController cartController = loader.getController();
            cartController.setCartDAO(cartDAO); // Inject shared CartDAO
            cartController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) CartButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }

    public void ToFood(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Food.fxml"));
            Parent newPageRoot = loader.load();

            FoodController foodController = loader.getController();
            foodController.setCartDAO(cartDAO);
            foodController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();
            Scene newScene = new Scene(newPageRoot);
            stage.setScene(newScene);
            stage.setTitle("Food Page");
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void ToElectronics(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Electronics.fxml"));
            Parent newPageRoot = loader.load();

            ElectronicsController electronicsController = loader.getController();
            electronicsController.setCartDAO(cartDAO);
            electronicsController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();
            Scene newScene = new Scene(newPageRoot);
            stage.setScene(newScene);
            stage.setTitle("Electronics Page");
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
