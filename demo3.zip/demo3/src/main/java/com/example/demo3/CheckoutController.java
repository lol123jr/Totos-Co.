package com.example.demo3;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.DAO.CustomerDAO;
import com.example.demo3.Entity.CustomerEntity;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class CheckoutController {

    @FXML
    private ComboBox<String> paymentMethodComboBox;

    @FXML
    private Button SignOut;

    @FXML
    private TextArea checkoutSummary;

    private CustomerDAO customerDAO;
    private CartDAO cartDAO;
    private CustomerEntity loggedInCustomer;

    private static final double TAX_RATE = 0.10;

    @FXML
    public void initialize() {
        setupPaymentMethods(); // Populate payment methods during initialization
    }

    public void setLoggedInCustomer(CustomerEntity customer) {
        this.loggedInCustomer = customer;
        System.out.println("Logged-in Customer: " + (customer != null ? customer.getName() : "None"));
       // updateBalanceField();

    }

    public void setCartDAO(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
        System.out.println("CartDAO set: " + (cartDAO != null ? "Valid" : "Null"));
        displayCartSummary();
        displayCartSummary();
    }

    private void displayCartSummary() {
        if (cartDAO == null || cartDAO.getProducts().isEmpty()) {
            checkoutSummary.setText("Your cart is empty!");
            return;
        }

        double subtotal = cartDAO.calculateTotal();
        double taxes = subtotal * TAX_RATE;
        double finalTotal = subtotal + taxes;

        StringBuilder summary = new StringBuilder();
        summary.append("Checkout Summary:\n");
        summary.append(String.format("Subtotal: $%.2f\n", subtotal));
        summary.append(String.format("Taxes (%.0f%%): $%.2f\n", TAX_RATE * 100, taxes));
        summary.append(String.format("Final Total: $%.2f\n", finalTotal));

        checkoutSummary.setText(summary.toString());
    }

//    private void updateBalanceField() {
//        if (loggedInCustomer != null) balanceField.setText(String.format("%.2f", loggedInCustomer.getBalance()));
//    }

    private void setupPaymentMethods() {
        paymentMethodComboBox.getItems().addAll("Cash", "Visa", "Instapay");
    }

    @FXML
    public void handlePurchase() {
        if (loggedInCustomer == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Customer data is not available.");
            return;
        }

        if (cartDAO == null || cartDAO.getProducts().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Error", "Cart data is not available or the cart is empty.");
            return;
        }

        String paymentMethod = paymentMethodComboBox.getValue();
        if (paymentMethod == null || paymentMethod.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Please select a payment method.");
            return;
        }

        double totalCost = cartDAO.calculateTotal() * (1 + TAX_RATE);

        if (paymentMethod.equals("Cash")) {
            showAlert(Alert.AlertType.INFORMATION, "Purchase Successful", "Payment completed using Cash!");
            clearCartAfterPurchase();
        } else if (paymentMethod.equals("Visa") || paymentMethod.equals("Instapay")) {
            try {
                double customerBalance = loggedInCustomer.getBalance();

                if (customerBalance < totalCost) {
                    showAlert(Alert.AlertType.ERROR, "Insufficient Balance", "Your balance is not enough to complete the purchase.");
                    return;
                }

                loggedInCustomer.reduceBalance(totalCost);
                showAlert(Alert.AlertType.INFORMATION, "Purchase Successful", "Payment completed using " + paymentMethod + "!");
                clearCartAfterPurchase();
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Error", "An error occurred: " + e.getMessage());
            }
        }

    }

    private void clearCartAfterPurchase() {
        cartDAO.clear(); // Clear the cart after purchase
        checkoutSummary.setText("Your cart is now empty.");
        //updateBalanceField();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void SignOut() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();

            HelloController helloController = loader.getController();


            Stage stage = (Stage) SignOut.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }
}

