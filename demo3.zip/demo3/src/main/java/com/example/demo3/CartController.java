package com.example.demo3;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.Entity.CustomerEntity;
import com.example.demo3.Entity.ProductsEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class CartController {

    @FXML
    private TableView<ProductsEntity> cartTable;

    @FXML
    private TableColumn<ProductsEntity, String> productNameColumn;

    @FXML
    private TableColumn<ProductsEntity, Double> productPriceColumn;

    @FXML
    private TableColumn<ProductsEntity, Void> actionsColumn;

    @FXML
    private TextField CartTotalField;

    @FXML
    private TextArea CheckoutTextArea;

    @FXML
    private Button CheckoutButton;

    private CartDAO cartDAO;
    private ObservableList<ProductsEntity> cartData;

    private static final double TAX_RATE = 0.10;

    private CustomerEntity loggedInCustomer; // Reference to the logged-in customer

    public void setLoggedInCustomer(CustomerEntity customer) {
        this.loggedInCustomer = customer;
    }

    public void calculateAndDisplayTotalWithTaxes() {
        if (cartDAO == null || cartDAO.getProducts().isEmpty()) {
            CheckoutTextArea.setText("Your cart is empty!");
            return;
        }

        double subtotal = cartDAO.calculateTotal();
        double taxes = subtotal * TAX_RATE;
        double finalTotal = subtotal + taxes;

        StringBuilder receipt = new StringBuilder();
        receipt.append("Receipt:\n");
        receipt.append(String.format("Subtotal: $%.2f\n", subtotal));
        receipt.append(String.format("Taxes (%.0f%%): $%.2f\n", TAX_RATE * 100, taxes));
        receipt.append(String.format("Final Total: $%.2f\n", finalTotal));

        CheckoutTextArea.setText(receipt.toString());
    }



    public void setCartDAO(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
        this.cartData = FXCollections.observableArrayList(cartDAO.getProducts());
        cartTable.setItems(cartData);
        displayCartTotal(); // Ensure the total is displayed when the DAO is set
    }

    @FXML
    public void initialize() {
        // Set up the table columns
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Add action buttons to the actions column
        actionsColumn.setCellFactory(param -> new TableCell<>() {
            private final Button addButton = new Button("Add");
            private final Button removeButton = new Button("Remove");

            {
                // Define add button action
                addButton.setOnAction(event -> {
                    ProductsEntity product = getTableView().getItems().get(getIndex());
                    handleAddExtraItem(product);
                });

                // Define remove button action
                removeButton.setOnAction(event -> {
                    ProductsEntity product = getTableView().getItems().get(getIndex());
                    handleRemoveItem(product);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(5, addButton, removeButton);
                    setGraphic(buttons);
                }
            }
        });

        displayCartTotal(); // Display total when the controller is initialized
    }

    public void handleAddExtraItem(ProductsEntity product) {
        cartDAO.addProduct(product);
        refreshTable();
    }

    public void handleRemoveItem(ProductsEntity product) {
        cartDAO.removeProduct(product);
        refreshTable();
    }

    private void refreshTable() {
        // Refresh the TableView
        cartData.setAll(cartDAO.getProducts());
        displayCartTotal();
    }

    public void displayCartTotal() {
        if (cartDAO != null && cartDAO.getProducts() != null) {
            CartTotalField.setText(String.format("%.2f", cartDAO.calculateTotal()));
        } else {
            CartTotalField.setText("0.00");
        }
    }

    public void ToElectronic(ActionEvent event) {
        try {
            // Load the new FXML file (Electronics.fxml) for the Electronic section
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Electronics.fxml"));
            Parent newPageRoot = loader.load();  // Load the root of the new FXML

            // Pass the CartDAO to the new controller
            ElectronicsController electronicsController = loader.getController();
            electronicsController.setCartDAO(cartDAO);

            // Get the current stage (window) from the event source
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

            // Create a new scene with the new FXML layout and set it on the current stage
            Scene newScene = new Scene(newPageRoot);
            stage.setScene(newScene);

            // Optionally, update the window title
            stage.setTitle("Electronic Page");

            // Show the new scene
            stage.show();
        } catch (Exception ex) {
            // Handle any errors (e.g., if the FXML file is not found)
            ex.printStackTrace();
        }
    }

    public void ToCheckout() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
            Parent root = loader.load();

            CheckoutController checkoutController = loader.getController();
            checkoutController.setCartDAO(cartDAO); // Inject shared CartDAO
            checkoutController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) CheckoutButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle exception if loading FXML fails
        }
    }


}
