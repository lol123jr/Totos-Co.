package com.example.demo3;

import com.example.demo3.DAO.ProductsDAO;
import com.example.demo3.Entity.ProductsEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ModifyMenuController {

    @FXML
    private TableView<ProductsEntity> productsTable;

    @FXML
    private TableColumn<ProductsEntity, String> productNameColumn;

    @FXML
    private TableColumn<ProductsEntity, Double> productPriceColumn;

    @FXML
    private TextField productNameField;

    @FXML
    private TextField productPriceField;

    @FXML
    private TextField productCategoryField;  // Category input field

    private ElectronicsController electronicsController;

    private ObservableList<ProductsEntity> productsList = FXCollections.observableArrayList();

    private ProductsDAO productsDAO;

    // Setter method to pass ProductsDAO from another controller
    public void setProductsDAO(ProductsDAO productsDAO) {
        this.productsDAO = productsDAO;
        loadProducts();  // Load products when the DAO is set
    }

    @FXML
    private void initialize() {
        // Set up table columns
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Bind the productsList to the table view
        productsTable.setItems(productsList);
    }

    private void loadProducts() {
        // Load all products from the DAO and display them in the table view
        if (productsDAO != null) {
            productsList.clear(); // Clear existing list before loading new data
            productsList.addAll(productsDAO.getAllProducts());
        } else {
            System.out.println("ProductsDAO is null. Cannot load products.");
        }
    }

    @FXML
    private void handleAddProduct(ActionEvent event) {
        String name = productNameField.getText();
        String priceText = productPriceField.getText();
        String category = productCategoryField.getText();  // Get the category entered by the user

        if (name.isEmpty() || priceText.isEmpty() || category.isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return;
        }

        try {
            double price = Double.parseDouble(priceText);
            ProductsEntity newProduct = new ProductsEntity(0, name, price, category);  // Use the entered category

            // Add the product to the DAO and refresh the list
            productsDAO.addProduct(newProduct);
            productsList.add(newProduct);  // Add it to the ObservableList to update the UI

            // Notify ElectronicsController to update the list
            if (electronicsController != null) {
                electronicsController.addProductToTable(newProduct); // Add to ElectronicsController's table
            }

            clearFields();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid price format.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleUpdateProduct(ActionEvent event) {
        ProductsEntity selectedProduct = productsTable.getSelectionModel().getSelectedItem();

        if (selectedProduct == null) {
            showAlert("Error", "No product selected.", Alert.AlertType.ERROR);
            return;
        }

        String name = productNameField.getText();
        String priceText = productPriceField.getText();
        String category = productCategoryField.getText();  // Get the category entered by the user

        if (name.isEmpty() || priceText.isEmpty() || category.isEmpty()) {
            showAlert("Error", "Please fill in all fields.", Alert.AlertType.ERROR);
            return;
        }

        try {
            double price = Double.parseDouble(priceText);
            selectedProduct.setProductName(name);
            selectedProduct.setPrice(price);
            selectedProduct.setCategory(category);  // Set the entered category

            // Update the product in the DAO and refresh the list
            productsDAO.updateProduct(selectedProduct);
            productsTable.refresh();  // Refresh the table view to reflect the changes

            // Notify ElectronicsController to update the list
            if (electronicsController != null) {
                electronicsController.modifyProductInTable(selectedProduct); // Modify product in ElectronicsController's table
            }

            clearFields();
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid price format.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleDeleteProduct(ActionEvent event) {
        ProductsEntity selectedProduct = productsTable.getSelectionModel().getSelectedItem();

        if (selectedProduct == null) {
            showAlert("Error", "No product selected.", Alert.AlertType.ERROR);
            return;
        }

        // Delete the product from the DAO and update the list
        productsDAO.deleteProduct(selectedProduct.getProductID());
        productsList.remove(selectedProduct);  // Remove the product from the ObservableList

        // Notify ElectronicsController to update the list
        if (electronicsController != null) {
            electronicsController.removeProductFromTable(selectedProduct); // Remove from ElectronicsController's table
        }
    }

    private void clearFields() {
        productNameField.clear();
        productPriceField.clear();
        productCategoryField.clear();  // Clear the category field
    }

    private void showAlert(String title, String content, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    private void goToAdmin(ActionEvent event) {
        try {
            // Load the Admin.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Admin.fxml"));
            Parent root = loader.load();

            // Get the current stage and set the new scene
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);

            // Show the new scene
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Handle any errors (e.g., FXML not found)
        }
    }
}
