package com.example.demo3.Entity;

public enum PaymentMethod {

        CASH, CREDIT_CARD, INSTA_PAY

}
