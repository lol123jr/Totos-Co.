package com.example.demo3.Entity;

import java.util.List;






public class CustomerEntity extends UserEntity {
    private double Balance;
    private String Address;
    private Gender gender;
    private List<String> Interests;
    private  CartEntity cart;


    public CustomerEntity(String username, String password, String DateOfBirth, double balance, String address,
                          Gender gender, List<String> interests) {

        super(username, password, DateOfBirth);
        this.Balance = balance;
        this.Address = address;
        this.gender = gender;
        this.Interests = interests;
        this.cart = new CartEntity(this);

    }

    public void reduceBalance(double amount) {
        if (this.getBalance() >= amount) {
            this.setBalance(this.getBalance() - amount);  // Update balance
        } else {
            throw new IllegalArgumentException("Insufficient balance!");
        }
    }

    public String getName(){
        return super.username;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getAddress() {
        return Address;
    }

    public void setInterests(List<String> interests) {
        Interests = interests;
    }

    public List<String> getInterests() {
        return Interests;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Gender getGender() {
        return gender;
    }

    public double getBalance() {
        return Balance;
    }

    public void setBalance(double balance) {
        Balance = balance;
    }

    public CartEntity getCart() {
        return cart;
    }

    public void setCart(CartEntity cart) {
        this.cart = cart;
    }

    @Override
    public String getUsername() {
        return super.getUsername();
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    public String toString() {
        return String.format("Username: %s\nBalance: %.2f\nAddress: %s\nGender: %s\nInterests: %s\n\n",
                getUsername(), Balance, Address, gender, String.join(", ", Interests));
    }

}