package com.example.demo3.Service;

import com.example.demo3.DAO.*;
import com.example.demo3.Entity.*;
import com.example.demo3.Database.*;

public class CustomerService {

    private OrderDAO orderDAO;  // Order DAO to handle order-related actions

    public CustomerService() {
        this.orderDAO = new OrderDAO();  // Initialize OrderDAO
    }

    // Add a product to the customer's cart
    public void addProductToCart(int productId, CustomerEntity customer) {
        CustomerDAO customerDAO = new CustomerDAO(customer);  // Initialize CustomerDAO with the customer context
        ProductsEntity product = findProductById(productId);
        if (product != null) {
            customerDAO.addToCart(product);  // Add to cart
            System.out.println("Product added to cart: " + product.getProductName());
        } else {
            System.out.println("Product not found.");
        }
    }

    // Remove a product from the customer's cart
    public void removeProductFromCart(int productId, CustomerEntity customer) {
        CustomerDAO customerDAO = new CustomerDAO(customer);  // Initialize CustomerDAO with the customer context
        ProductsEntity product = findProductById(productId);
        if (product != null) {
            customerDAO.removeFromCart(product);  // Remove from cart
            System.out.println("Product removed from cart: " + product.getProductName());
        } else {
            System.out.println("Product not found.");
        }
    }

    // Display all products in the customer's cart
    public void displayCartContents(CustomerEntity customer) {
        CustomerDAO customerDAO = new CustomerDAO(customer);  // Initialize CustomerDAO with the customer context
        customerDAO.displayCartContents();  // Now, using CustomerDAO to display cart contents
    }

    // Perform checkout
    public void checkout(CustomerEntity customer) {
        CustomerDAO customerDAO = new CustomerDAO(customer);  // Initialize CustomerDAO with the customer context
        double totalAmount = orderDAO.calculateTotal(customerDAO.getCart().getProducts());  // Calculate total amount

        if (customer.getBalance() >= totalAmount) {
            customerDAO.reduceBalance(totalAmount);  // Reduce balance for the customer
            OrderEntity order = new OrderEntity(customer, customer.getCart().getProducts(), PaymentMethod.CASH);
            Database.orders.add(order);  // Add order to the database
            customer.getCart().clear();  // Clear the cart after purchase
            System.out.println("Order placed successfully! Total: " + totalAmount);
        } else {
            System.out.println("Insufficient balance to complete the order.");
        }
    }

    // Find a product by its ID (helper method)
    private ProductsEntity findProductById(int productId) {
        for (ProductsEntity product : Database.products) {
            if (product.getProductID() == productId) {
                return product;
            }
        }
        return null;
    }

    // Get the current balance of the customer
    public double getBalance(CustomerEntity customer) {
        CustomerDAO customerDAO = new CustomerDAO(customer);  // Initialize CustomerDAO with the customer context
        return customerDAO.getBalance();  // Return balance from DAO
    }

    public boolean login(String username, String password) {
        // Check the list of admins (assuming Database contains the list of admins)
        for (AdminEntity admin : Database.admins) {
            // Call the login method in AdminEntity (or you can directly check credentials here)
            if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                System.out.println("Login successful for admin: " + username);
                return true;  // Valid credentials
            }
        }
        System.out.println("Login failed. Invalid username or password.");
        return false;  // Invalid credentials
    }


}
