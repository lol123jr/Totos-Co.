package com.example.demo3.Entity;

public class ProductsEntity {
    private int productID;
    private String ProductName;
    private double price;
    private String Category;


   public ProductsEntity(int productID, String name, double price, String category) {
        this.productID = productID;
        this.ProductName = name;
        this.price = price;
        this.Category = category;
   }

    public void setCategory(String category) {
        Category = category;
    }

    public String getCategory() {
        return Category;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String name) {
        ProductName = name;
    }

    public String toString() {
        return "Product{" +
                "productID=" + productID +
                ", name='" + ProductName + '\'' +
                ", price=" + price +
                ", category='" + Category + '\'' +
                '}';
    }
}



