package com.example.demo3;

import com.example.demo3.DAO.CartDAO;
import com.example.demo3.Database.Database;
import com.example.demo3.Entity.ProductsEntity;
import com.example.demo3.Entity.CustomerEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.util.Callback;

public class FoodController {

    @FXML
    private TableView<ProductsEntity> foodTable;

    @FXML
    private TableColumn<ProductsEntity, String> foodNameColumn;

    @FXML
    private TableColumn<ProductsEntity, Double> foodPriceColumn;

    @FXML
    private TableColumn<ProductsEntity, Void> actionColumn;

    @FXML
    private Button CartButton;

    private CartDAO cartDAO;
    private CustomerEntity loggedInCustomer;

    private ObservableList<ProductsEntity> foodItems = FXCollections.observableArrayList();

    public void setLoggedInCustomer(CustomerEntity customer) {
        this.loggedInCustomer = customer;
        System.out.println("Logged in customer: " + customer.getUsername());
    }

    public void setCartDAO(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
    }

    @FXML
    private void initialize() {
        // Initialize table columns
        foodNameColumn.setCellValueFactory(new PropertyValueFactory<>("productName"));
        foodPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        // Load food items dynamically from the database
        loadFoodItemsFromDatabase();

        // Set the items to the table
        foodTable.setItems(foodItems);

        // Add "Add to Cart" buttons to the action column
        addButtonToTable();
    }

    private void loadFoodItemsFromDatabase() {
        // Get all products with category "Food" from the Database
        foodItems.clear(); // Clear the existing list first
        foodItems.addAll(Database.getFoodProducts());  // Fetching the "Food" category products
    }

    // Add a product to the table
    public void addProductToTable(ProductsEntity newProduct) {
        if ("Food".equals(newProduct.getCategory())) {
            foodItems.add(newProduct);  // Only add if it's a "Food" category product
        }
    }

    // Remove a product from the table
    public void removeProductFromTable(ProductsEntity productToRemove) {
        foodItems.remove(productToRemove);
    }

    // Modify an existing product in the table
    public void modifyProductInTable(ProductsEntity modifiedProduct) {
        int index = -1;
        for (int i = 0; i < foodItems.size(); i++) {
            if (foodItems.get(i).getProductID() == modifiedProduct.getProductID()) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            foodItems.set(index, modifiedProduct);
        }
    }

    // Add "Add to Cart" buttons to the action column
    private void addButtonToTable() {
        Callback<TableColumn<ProductsEntity, Void>, TableCell<ProductsEntity, Void>> cellFactory = param -> new TableCell<>() {
            private final Button addButton = new Button("Add to Cart");

            {
                addButton.setOnAction(event -> {
                    ProductsEntity product = getTableView().getItems().get(getIndex());
                    if (product != null) {
                        if (cartDAO == null) {
                            System.out.println("Error: CartDAO is not initialized.");
                            return;
                        }
                        // Add product to cart
                        cartDAO.addProduct(product);
                        System.out.println(product.getProductName() + " has been added to the cart.");
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(addButton);
                }
            }
        };

        actionColumn.setCellFactory(cellFactory);
    }

    // Navigate to the Cart page
    public void goToCart() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Cart.fxml"));
            Parent root = loader.load();

            CartController cartController = loader.getController();
            cartController.setCartDAO(cartDAO);
            cartController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) CartButton.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Navigate to the Electronics page
    public void ToElectronic(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Electronics.fxml"));
            Parent newPageRoot = loader.load();

            ElectronicsController electronicsController = loader.getController();
            electronicsController.setCartDAO(cartDAO);
            electronicsController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();
            Scene newScene = new Scene(newPageRoot);
            stage.setScene(newScene);
            stage.setTitle("Electronic Page");
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Navigate to the Vegetables page
    public void ToVegetables(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Vegetables.fxml"));
            Parent newPageRoot = loader.load();

            VegetablesController vegetablesController = loader.getController();
            vegetablesController.setCartDAO(cartDAO);
            vegetablesController.setLoggedInCustomer(loggedInCustomer);

            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();
            Scene newScene = new Scene(newPageRoot);
            stage.setScene(newScene);
            stage.setTitle("Vegetables Page");
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
