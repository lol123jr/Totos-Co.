package com.example.demo3.DAO;

import com.example.demo3.Entity.ProductsEntity;

public interface adminInterface {
    public void showAllCustomers();
    public void showAllProducts();
    public void showAllOrders();
    public void addProduct(ProductsEntity product);
    public void removeProduct(int productID);





}
