package com.example.demo3.Entity;

import java.util.List;
import com.example.demo3.DAO.OrderDAO;



public class OrderEntity {
    private CustomerEntity customer;
    private List<ProductsEntity> products;
    private double totalAmount;
    private PaymentMethod paymentMethod;

    // Constructor
    public OrderEntity(CustomerEntity customer, List<ProductsEntity> products, PaymentMethod paymentMethod) {
        this.customer = customer;
        this.products = products;
        this.paymentMethod = paymentMethod;
        this.totalAmount = OrderDAO.calculateTotal(products); // Calculate total using OrderDAO
    }

    // Getter and Setter methods
    public void setCustomer(CustomerEntity customer) {
        this.customer = customer;
    }

    public CustomerEntity getCustomer() {
        return customer;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public List<ProductsEntity> getProducts() {
        return products;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public void setProducts(List<ProductsEntity> products, OrderDAO orderDAO) {
        this.products = products;
        this.totalAmount = orderDAO.calculateTotal(products); // Recalculate total when products change
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "Order{" +
                "customer=" + customer.getUsername() +
                ", totalAmount=" + totalAmount +
                ", paymentMethod=" + paymentMethod +
                '}';
    }
}
