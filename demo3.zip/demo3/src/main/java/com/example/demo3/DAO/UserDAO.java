package com.example.demo3.DAO;

import com.example.demo3.Entity.*;
public abstract class UserDAO {
    protected String username;
    protected String password;
    protected UserEntity userEntity;


    public abstract boolean Login(String username, String password);

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public UserEntity getUserEntity() {
        return userEntity;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

}
