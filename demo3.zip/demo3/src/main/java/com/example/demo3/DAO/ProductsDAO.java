package com.example.demo3.DAO;

import com.example.demo3.Database.Database;
import com.example.demo3.Entity.ProductsEntity;

import java.util.ArrayList;
import java.util.List;

public class ProductsDAO {


    public List<ProductsEntity> getAllProducts() {
        return Database.products;  // Simulate fetching from database
    }



    public void addProduct(ProductsEntity product) {
        Database.products.add(product);  // Simulate adding to database
    }

    /**
     * Update an existing product in the database.
     *
     * @param product the product to update.
     */
    public void updateProduct(ProductsEntity product) {
        // Simulate updating the product in the database
        for (int i = 0; i < Database.products.size(); i++) {
            if (Database.products.get(i).getProductID() == product.getProductID()) {
                Database.products.set(i, product);  // Update product
                break;
            }
        }
    }


    public void deleteProduct(int productID) {
        Database.products.removeIf(product -> product.getProductID() == productID);  // Simulate deleting from database
    }


    public int getProductID(ProductsEntity product) {
        return product.getProductID();
    }


    public String getProductName(ProductsEntity product) {
        return product.getProductName();
    }


    public void setProductName(ProductsEntity product, String name) {
        product.setProductName(name);
    }


    public void setCategory(ProductsEntity product, String category) {
        product.setCategory(category);
    }

    /**
     * Get the price of a product.
     *
     * @param product the product entity.
     * @return the product price.
     */
    public double getPrice(ProductsEntity product) {
        return product.getPrice();
    }

    /**
     * Set the price of a product.
     *
     * @param product the product entity.
     * @param price   the new product price.
     */
    public void setPrice(ProductsEntity product, double price) {
        product.setPrice(price);
    }
}
