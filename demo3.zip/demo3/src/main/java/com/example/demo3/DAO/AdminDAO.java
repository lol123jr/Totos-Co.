package com.example.demo3.DAO;

import java.util.Scanner;
import com.example.demo3.Entity.*;
import com.example.demo3.Database.*;
import java.util.List;

public class AdminDAO extends UserDAO implements adminInterface {

    public static void updateProductDetails(int productId, Scanner scanner) {
        ProductsEntity product = null;

        // Find the product by ID
        for (ProductsEntity p : Database.products) {
            if (p.getProductID() == productId) {
                product = p;
                break;
            }
        }

        if (product == null) {
            System.out.println("Product with ID " + productId + " not found!");
            return;
        }

        // Update product details
        System.out.println("Updating details for Product ID: " + productId);
        System.out.println("Current Name: " + product.getProductName());
        System.out.print("Enter new name (or press Enter to keep current): ");
        String newName = scanner.nextLine();
        if (!newName.isEmpty()) {
            product.setProductName(newName);
        }

        System.out.println("Current Price: " + product.getPrice());
        System.out.print("Enter new price (or press Enter to keep current): ");
        String newPriceInput = scanner.nextLine();
        if (!newPriceInput.isEmpty()) {
            try {
                double newPrice = Double.parseDouble(newPriceInput);
                product.setPrice(newPrice);
            } catch (NumberFormatException e) {
                System.out.println("Invalid price entered. Keeping the current price.");
            }
        }

        System.out.println("Current Category: " + product.getCategory());
        System.out.print("Enter new category (or press Enter to keep current): ");
        String newCategory = scanner.nextLine();
        if (!newCategory.isEmpty()) {
            product.setCategory(newCategory);
        }

        System.out.println("Product details updated successfully!");
    }

    @Override
    public void showAllCustomers() {
        Database.customers.forEach(System.out::println);
    }

    @Override
    public void showAllOrders() {
        Database.orders.forEach(System.out::println);
    }

    @Override
    public void addProduct(ProductsEntity product) {
        Database.products.add(product);
    }

    @Override
    public void removeProduct(int productId) {
        Database.products.removeIf(p -> p.getProductID() == productId);
    }

    @Override
    public void showAllProducts() {
        if (Database.products.isEmpty()) {
            System.out.println("No products available.");
        } else {
            System.out.println("All Products:");
            for (ProductsEntity p : Database.products) {
                System.out.println(p);
            }
        }
    }


    @Override
    public boolean Login(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

}
