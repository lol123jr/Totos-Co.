package com.example.demo3.Service;

import com.example.demo3.DAO.ProductsDAO;
import com.example.demo3.Entity.ProductsEntity;
import java.util.List;

public class ProductService {

    private ProductsDAO productsDAO;  // DAO instance to interact with product data

    public ProductService() {
        this.productsDAO = new ProductsDAO();  // Initialize ProductsDAO for this service
    }

    // Add a new product to the list
    public void addProduct(ProductsEntity product, List<ProductsEntity> products) {
        products.add(product);
        System.out.println("Product added: " + product.getProductName());
    }

    // Update the product's name
    public void updateProductName(ProductsEntity product, String newName) {
        productsDAO.setProductName(product, newName);
        System.out.println("Product name updated to: " + newName);
    }

    // Update the product's price
    public void updateProductPrice(ProductsEntity product, double newPrice) {
        productsDAO.setPrice(product, newPrice);
        System.out.println("Product price updated to: " + newPrice);
    }

    // Update the product's category
    public void updateProductCategory(ProductsEntity product, String newCategory) {
        productsDAO.setCategory(product, newCategory);
        System.out.println("Product category updated to: " + newCategory);
    }

    // Remove a product from the list
    public void removeProduct(ProductsEntity product, List<ProductsEntity> products) {
        products.remove(product);
        System.out.println("Product removed: " + product.getProductName());
    }

    // Get product details as a string
    public String getProductDetails(ProductsEntity product) {
        return product.toString();
    }

    // Get product's price
    public double getProductPrice(ProductsEntity product) {
        return productsDAO.getPrice(product);
    }

    // Get all products from the list (can be used if you want to display all products)
    public List<ProductsEntity> getAllProducts(List<ProductsEntity> products) {
        return products;
    }
}

