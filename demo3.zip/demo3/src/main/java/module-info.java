module com.example.demo3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    exports com.example.demo3;

    exports com.example.demo3.Database;
    exports com.example.demo3.Entity;
    exports com.example.demo3.DAO;
    exports com.example.demo3.Service;

    opens com.example.demo3 to javafx.fxml;
}